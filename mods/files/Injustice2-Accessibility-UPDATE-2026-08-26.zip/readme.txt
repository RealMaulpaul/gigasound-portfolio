Injustice 2 Accessibility (AccessKit build, 26 August 2026)
Update package, mod files only

WHAT THIS IS

The newer version of the Injustice 2 screen reader mod, as two files. This is
an upgrade only. It assumes you already have the accessibility mod installed and
working. If you do not, get the full package instead, which includes the loader,
launcher and installer.


HOW TO UPDATE

1. Close Injustice 2 completely.
2. Go to your Injustice 2 install folder and then into:
   Binaries\Retail\Reloaded-II\Mods\Injustice2.Accessibility
   The full usual path is:
   C:\Program Files (x86)\Steam\steamapps\common\Injustice2\Binaries\Retail\Reloaded-II\Mods\Injustice2.Accessibility
   If you are not sure where the game is, in Steam go to Injustice 2, open
   Properties, then Installed Files, then Browse.
3. If you want a way back, copy the files already in that folder whose names
   start with Injustice2.Accessibility into a folder somewhere safe first.
4. Copy the two files from this zip into that folder, replacing the existing
   ones:
   Injustice2.Accessibility.dll
   Injustice2.Accessibility.deps.json
   If there is an old Injustice2.Accessibility.pdb file already sitting in that
   folder, delete it. It is a leftover debug file and is not needed.
5. Launch the game from Steam as you normally do. You should hear
   "Injustice 2 accessibility loaded".

Nothing else changes. You do not need to run the installer again, and you do not
need to touch any settings.


WHAT IS NEW IN THIS BUILD

Move lists now carry the frame data. On a move you hear the name and position, a
short note on what the move does, and then the numbers: move type, start up,
active, recover, damage, block damage, block advantage, hit advantage and
cancel. Columns the game leaves empty are skipped rather than read as "not
applicable". Moves the game marks as ability moves, or as affected by strength
or by an ability, say so. Section headings such as "sound waves" read their own
name instead of repeating the move you were last on. Tagging a move with the Y
button announces the new count, for example "tagged, 1 of 10".

Diagnostic logging is now off unless you ask for it. Earlier builds wrote a
detailed log the whole time you played, which grew to megabytes for no reason on
a machine that was not chasing a bug. Press F10 when you want it; see the note
about logging below.


ALSO IN RECENT BUILDS

Customization no longer bleeds text from screens you already left.

Gear numbers now say which number is which, for example "loadout total strength
1200" versus "this piece strength 40", and a change like plus 14 is read as
"14 higher than equipped".

Gear unlocked after a match is announced as it is revealed, instead of only
after you press a button.

The dyes and shaders screen, which was completely silent, now reads the name,
price and unlock message.

Mother box and loot drops say which character a piece of gear is for.

Another player's online profile and hero card now read.

Several announcements that used to speak only once per session, and then go
quiet for the rest of the session, now repeat properly.


KEYS

All of these only work while the game window is in the foreground.

F1   Read the whole current screen. This is the catch all. If a screen says
     nothing on its own, press F1.
F4   Read details for whatever you are on. In a tutorial lesson it re-reads the
     full lesson text; on a piece of gear it reads the complete gear card with
     slot, character, stats, set bonus and ability; anywhere else it falls back
     to reading the whole screen.
F6   Take a screenshot into the mod folder. This is a troubleshooting tool for
     reporting problems, not something you need in normal play.
F7   Repeat the control hints for this screen, meaning what each button does
     here.
F8   Repeat the last story mode branching choice.
F9   Repeat the last thing that was spoken, in full.
F10  Turn diagnostic logging on or off. It is off unless you switch it on.

Controller: pushing the right stick down, or clicking it in, repeats the last
line, the same as F9. In a tutorial lesson it re-reads the lesson instead.

Note that F4 is the "read details" key in this build. Older builds used F2 for
that; F2 was freed up so the separate I2Hook cheat panel can use it.


ABOUT LOGGING

The mod keeps one small file, AccessKit.log, which records whether it loaded and
what it hooked. That one is always written and stays small.

The detailed diagnostic logs are off. They only start if you press F10, and they
stop again when you press F10 a second time or close the game. If you are
reporting a problem, press F10 as soon as the game loads, go and do the thing
that reads wrong, then send the files whose names start with AccessKit_ from the
mod folder.

Coming from an older build, that folder probably already holds a large
AccessKit_dump.log from back when logging ran all the time. It is safe to delete
any file whose name starts with AccessKit_ while the game is closed.


KNOWN ROUGH EDGES

The direction announced during story mode quick time events can be wrong.

The character tutorial list, where you pick which tutorial to run, does not read
well yet.

Guild screens other than the join page, the sell popup for individual items, and
some detail panels are not covered yet.


IF SOMETHING GOES WRONG

If the game stops speaking after the update, put back the files you copied aside
in step 3 and you are exactly where you were before.


CREDITS

The original Injustice 2 accessibility mod, the launcher and the installer are
by Amethyst. This build extends that work with a lot of additional screen
coverage. The loader underneath is Reloaded II by Sewer56, and speech goes
through the prism library.
