﻿Mortal Kombat 11 accessibility mod
Version 0.6.0


WHAT THIS IS

Mortal Kombat 11 has no screen reader support at all. Its menus are drawn as pictures, so
nothing you normally rely on can see them.

This mod reads those menus aloud. It hooks the game's own user interface code, so it speaks
the real text the game is drawing, and it knows which item you are actually sitting on rather
than guessing from the screen.

It speaks through NVDA or JAWS if one of them is running. If neither is running it falls back
to the Windows built in voice, so it still works on its own.

It is a menu reader. It does not play the game for you, and it does not read anything during
a fight beyond the fight starting.


WHAT IS NEW IN VERSION 0 POINT 6

Reporting a problem is now one key.

Press F7 at any time and the mod writes a single zip file into your Documents folder, in
a folder called MK11 Accessibility. It contains every log, a snapshot of the screen you
were on, and a summary of your setup. Send me that file and I have everything I need.

You no longer have to find the mod folder, delete an old log, create a file called debug
dot txt, or work out which of two files to send. All of that is gone. Press F7, attach the
file. Your Windows account name is removed from everything in it before it is written.

There is also now a way to update without downloading anything by hand. In that same
Documents folder there is a file called Check for Updates. Run it and it will tell you
whether there is a newer version, and offer to install it for you. It checks the same
website you got this from, and it refuses to install anything that does not match what
the site says it should be.

The mod also no longer refuses to load just because the game executable has an unexpected
name. Two people reported that the Microsoft Store and Game Pass copy said "mod loaded,
but this game is not supported". That version is not working yet, but the mod now tries
rather than giving up, and it records enough about your copy of the game for me to see
exactly what is different. If you have that version, press F7 and send me the file.

Nothing about how the menus read has changed in this version.


WHAT IS NEW IN VERSION 0 POINT 5

This version is about the Krypt, which was the last big part of the game with nothing at all
in it, and about one bug that made the Krypt unusable even for the parts that did work.

Finding things in the Krypt. The Krypt is not a menu. It is a three dimensional world you
walk around in, so none of the menu reading applies to it. There is now a beacon that points
you at the things in the world around you using sound.

It works like a map that always faces north, rather than like something attached to your
character. That matters, because the camera swings around as you walk and anything tied to
the camera became unreadable the moment you turned. Three things carry the information.

Which side the object is on is carried by which ear the sound is in. Full left means it is
due west of you, full right means due east.

Whether it is above or below you is carried by pitch. Higher means it is above you, lower
means below.

How far away it is is carried by how often the sound repeats. Far away it ticks about once
every two seconds. As you get closer it speeds up, until it is almost continuous when you
are on top of it. This is the part to steer by. Walk, and if the ticking speeds up you are
going the right way. If it slows down, turn around.

North and south are not carried by the sound, because the left and right channels and the
pitch are both already spoken for. Instead the mod tells you the compass bearing out loud
when the target changes. Both the speech and the sound use compass directions, so they can
never contradict each other.

When you reach something the mod says "reached it, next" and moves on to the next nearest
object, so it does not keep pinging at a chest you already opened.

Not everything it points at is a chest. The mod can see the objects the game has placed in
the world, but it cannot yet tell which of them are chests, which are doors, and which are
scenery. Some of them cannot be reached at all. If the beacon is stuck on something useless,
press F8 to skip it and go to the next one.

The Krypt coordinates are no longer read aloud. In the previous version the mod read the
coordinate display in the corner of the Krypt screen out loud twelve times a second, so you
heard something like "10594, 39" endlessly, over the top of everything else. That is fixed.

Please treat the Krypt beacon as experimental. One person has used it, and it did find a
chest, which is more than the previous version could do, but the tuning is a first attempt.


KEYS THE MOD USES

These only work while the game window is in front.

F11 turns the Krypt beacon on and off. It starts off.

F8 skips the thing the beacon is currently pointing at, and moves to the next one. Hold
control and press F8 to forget everything you have skipped or reached and start over.

F7 writes a complete bug report to your Documents folder, in a folder called MK11
Accessibility. If anything is wrong, press F7 while it is happening and send me that file.
This is the single most useful thing you can do.

F9 writes a snapshot of just the current screen to a text file next to the log. F7 already
includes one of these, so you only need F9 if I ask for it specifically.


WHAT IS NEW IN VERSION 0 POINT 4

This version is mostly about Towers of Time, and about one thing that was not a bug in the
mod at all but felt like one.

Konsumables. If you opened the inventory with the right trigger and pressed the confirm
button, nothing happened, and there was no way to tell why. It turns out the game has two
konsumable screens that look identical. The one on the right trigger is only a viewer, and
nothing can be selected on it. The one where you actually equip konsumables is opened with
the X button on the screen just before a match starts, after you have chosen your fighter.
The mod used to say "available" on the viewer, which made it sound like you could add the
item. It now says "view only" and names the screen you are on, and the screen before a match
now reads out its X button prompt so you can find the right one.

Tower details. Choosing a tower opened a panel that said nothing whatsoever. It now reads the
tower name, how many opponents, the difficulty, how many modifiers it has, and the tower's
own description, which is where the game hides restrictions like tag assist konsumables not
being allowed. It also reads the rewards, your high score and your rank. If the tower is
locked, it now says so and tells you which tower you have to finish first.

Towers that demand a particular fighter. Some towers only let you play as one character, and
the game shows this by greying out every other portrait, which is invisible to us. The tower
panel names the required fighter, and moving onto a portrait you cannot pick now says
"locked" and repeats the game's own wording, for example "Jade required".

The screen before a match. It used to say only "recommended konsumable" and then a word or
two of whatever else it caught. It now reads you against your opponent, each modifier with
what it does, how many konsumables you have equipped, and the button that opens the
konsumable screen.

Character select is faster. A change in the previous version made every move wait a fraction
of a second before speaking. That is gone and it now speaks immediately.

Choosing player two works. In a local two player match, moving player two's cursor read out
the fighter player one had already locked in, over and over, instead of the one you were
pointing at.

Random select is quiet. The random spin moves the cursor across the whole roster, and the mod
used to shout a name on every hop. It now stays silent while it spins and lets the game's own
announcer tell you who you got.

As with the last version, please treat all of this as new. It has had one person testing it.


WHAT WAS NEW IN VERSION 0 POINT 3

A lot. Version 0 point 2 was the first build anyone else saw, and most of the game beyond the
main menus has been worked on since.

Towers of Time now works. Each tower portal tells you the tower name, what kind of tower it
is, how hard it is out of five, which portal you are on, how long it has left before it
rotates away, and what it pays out. Before this, a portal said only its name, and the names
are jokes like "help" and "pit fighter", so it was impossible to tell them apart. Pressing Y
on that screen opens the Race Against Time board, which now reads out instead of being
completely silent.

End of a match is read: who won, whether it ended in a fatality or a brutality, and what you
were paid in koins, souls and hearts.

The move list reads frame data, what each move actually does, and the move properties. Tagging
a move with Y now says so.

Abilities in kustomize read properly: whether an ability is equipped, what it costs, how many
of your three slots are used, what it conflicts with, and what it does. Swapping one says what
replaced what.

On character select, moving the carousel reads the whole variation summary, including the
abilities with their inputs and the AI ratings. You do not have to press Y for it.

Button names now match what you are actually holding. If you are on the keyboard it says the
key, and if you are on a pad it says the button in that pad's own language, Xbox or
PlayStation. It follows you if you swap mid session.

Also read: tower reward cards at the end of a run, the konsumable inventory screen, and the
variations panel in the practice pause menu.

Please treat all of this as new. Most of it has had one person testing it, and the Towers of
Time portal cards in particular have had none.


WHAT YOU NEED

1. Mortal Kombat 11 on Windows, the Steam version.
2. The Microsoft dot NET 9 Desktop Runtime. This is the one thing most people will not
   already have. If the mod stays silent, this is almost certainly why. Get it free from
   Microsoft at dotnet dot microsoft dot com slash download, and choose the dot NET Desktop
   Runtime, version 9, x64.
3. NVDA or JAWS if you want it to speak through your usual voice. Optional.

You do not need administrator rights. You do not need to change any Windows settings.


HOW TO INSTALL

1. Unzip this folder anywhere you like. Your downloads folder is fine. Do not unzip it into
   the game folder.
2. Run Install dot bat.
3. It will try to find Mortal Kombat 11 by itself, including on other drives. If it cannot,
   it will ask you to type or paste the full path to your Mortal Kombat 11 folder. That is
   the folder containing a folder called Binaries.
4. It will tell you when it is done.

Close the game first if it is running. The installer will stop and tell you if it is.


HOW TO PLAY

Start the game with MK11 dot exe.

Do not use MK11 underscore DX12 dot exe. That is a different version of the game and the mod
will refuse to attach to it rather than risk breaking anything.

If it worked, you will hear "Mortal Kombat 11 accessibility loaded" a few seconds after the
game window appears. Then move around any menu and it will speak.


WHAT IT READS TODAY

Main menus and the option screens, including slider values as numbers while you drag them.

Story mode, including chapter select, and the "choose your fighter" moments where the game
gives you a few seconds to pick a side. It tells you which fighter is on the left and which
is on the right, and which way to push.

Character select, stage select, and the start of a match, so you know who is fighting.

The tutorial. It reads the objectives when a lesson starts and says when you have completed
one.

Kustomize. Gear, kosmetics, abilities and AI behaviour. On gear and kosmetic items it says
whether the item is locked, and where it comes from if it is. On abilities it reads the name,
how many of your three slots it costs, anything it conflicts with, and what it does.

Towers of Time. The portal map, the towers themselves, the konsumable screen, and the reward
cards you get at the end of a run.

The move list, with frame data, move descriptions and move properties.

The end of a match, including who won, how it ended, and what you earned.

The Krypt, partly. It reads chests and rewards when you reach them, and the beacon
described above helps you find them. See the section on version 0 point 5.


WHAT DOES NOT WORK YET

Walls in the Krypt. The beacon points you at objects, but nothing yet tells you that you
are about to walk into a wall, or which way a corridor runs. You will still get stuck on
scenery. This is the next thing to be built.

Knowing what a Krypt object actually is before you get there. The beacon says "object",
because the game does not label them in any way the mod can read yet.

Anything during an actual fight. You will not be told what your opponent is doing.

Online menus have had very little testing.


IF SOMETHING IS WRONG

Press F7 while the game is running. The mod says "bug report saved" and writes a zip file
into your Documents folder, in a folder called MK11 Accessibility. Send me that file and
say what you were doing and what you expected to hear. That is the whole process.

Two things worth checking first, because they cause most reports:

You need the dot NET 9 Desktop Runtime, x64, from Microsoft. Without it nothing loads.

Start the game with MK11 dot exe, not MK11 underscore DX12 dot exe.

If the mod says nothing at all and F7 does nothing either, then it never loaded, and the
zip cannot be written. In that case send me these two files instead:

Reloaded-II\Mods\MK11.Accessibility\MK11AccessKit.log
Binaries\Retail\MK11AccessKit_loader.log

Both are small plain text files inside your game folder.

One small warning about F7 and F9: pressing either one while a controller is plugged in
makes the game briefly think you switched to the keyboard, so the button prompts on screen
may change for a second. It is harmless.

Your antivirus may not like this mod, because loading itself into a game is what cheating
tools do. It only reads text out of the game, and it does not change any of the game's own
files. The source is available for anyone who wants to check.

This loads code into the game. It is meant for single player. Think twice before using it
in ranked online play.


HOW TO UNINSTALL

Run Uninstall dot bat, and it will remove it.

If you would rather do it by hand, delete this one file from your game folder:

Binaries\Retail\dinput8.dll

That is the only file the game ever loads. Deleting it fully disables the mod. The
Reloaded-II folder left behind does nothing on its own and can be deleted too if you want
it gone.

The mod does not change any of the game's own files, so there is nothing to repair or
verify afterwards.


THANKS

Please say what worked and what did not, and which screens said nothing. The screens that
say nothing are the useful bug reports, because they are the ones nobody has found yet.
