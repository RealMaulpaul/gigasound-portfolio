Mortal Kombat 11 accessibility mod
Version 0.2.0


WHAT THIS IS

Mortal Kombat 11 has no screen reader support at all. Its menus are drawn as pictures, so
nothing you normally rely on can see them.

This mod reads those menus aloud. It hooks the game's own user interface code, so it speaks
the real text the game is drawing, and it knows which item you are actually sitting on rather
than guessing from the screen.

It speaks through NVDA or JAWS if one of them is running. If neither is running it falls back
to the Windows built in voice, so it still works on its own.

It is a menu reader. It does not play the game for you, and it does not read anything during
a fight beyond the fight starting.


WHAT YOU NEED

1. Mortal Kombat 11 on Windows, the Steam version.
2. The Microsoft dot NET 9 Desktop Runtime. This is the one thing most people will not
   already have. If the mod stays silent, this is almost certainly why. Get it free from
   Microsoft at dotnet dot microsoft dot com slash download, and choose the dot NET Desktop
   Runtime, version 9, x64.
3. NVDA or JAWS if you want it to speak through your usual voice. Optional.

You do not need administrator rights. You do not need to change any Windows settings.


HOW TO INSTALL

1. Unzip this folder anywhere you like. Your downloads folder is fine. Do not unzip it into
   the game folder.
2. Run Install dot bat.
3. It will try to find Mortal Kombat 11 by itself, including on other drives. If it cannot,
   it will ask you to type or paste the full path to your Mortal Kombat 11 folder. That is
   the folder containing a folder called Binaries.
4. It will tell you when it is done.

Close the game first if it is running. The installer will stop and tell you if it is.


HOW TO PLAY

Start the game with MK11 dot exe.

Do not use MK11 underscore DX12 dot exe. That is a different version of the game and the mod
will refuse to attach to it rather than risk breaking anything.

If it worked, you will hear "Mortal Kombat 11 accessibility loaded" a few seconds after the
game window appears. Then move around any menu and it will speak.


WHAT IT READS TODAY

Main menus and the option screens, including slider values as numbers while you drag them.

Story mode, including chapter select, and the "choose your fighter" moments where the game
gives you a few seconds to pick a side. It tells you which fighter is on the left and which
is on the right, and which way to push.

Character select, stage select, and the start of a match, so you know who is fighting.

The tutorial. It reads the objectives when a lesson starts and says when you have completed
one.

Kustomize. Gear, kosmetics, abilities and AI behaviour. On gear and kosmetic items it says
whether the item is locked, and where it comes from if it is. On abilities it reads the name,
how many of your three slots it costs, anything it conflicts with, and what it does.

The Krypt, partly. It reads chests and rewards.


WHAT DOES NOT WORK YET

Moving around the Krypt itself. The Krypt is a three dimensional world you walk through
rather than a menu, so it needs a completely different approach and it has not been built
yet. You can hear chests when you reach them, but finding your way there is not solved.

Anything during an actual fight. You will not be told what your opponent is doing.

Online menus have had very little testing.


IF SOMETHING IS WRONG

There is a log at this path inside your game folder:

Reloaded-II\Mods\MK11.Accessibility\MK11AccessKit.log

It is a plain text file. It records whether the mod attached to the game and what it hooked.
If the mod is silent, this file usually says why in the first few lines.

There is a second log next to it, MK11AccessKit underscore loader dot log, in
Binaries\Retail, which covers the earlier stage of starting up.

To report a problem properly, create an empty text file called debug dot txt in the same
folder as the first log, then play again. That turns on a detailed recording of every piece
of text the game drew and everything the mod said, into MK11AccessKit underscore dump dot
log. Send that file along with a description of what you were doing.

Leave debug dot txt turned off the rest of the time. The detailed log grows to several
megabytes and never trims itself.

Your antivirus may be suspicious of this mod, because it works the same way many cheating
tools do, by loading itself into the game. It is not doing anything to the game other than
reading text. The source is not published yet; if enough people ask for it, it will be.

It has been used online, ranked included, without trouble.


HOW TO UNINSTALL

Run Uninstall dot bat, and it will remove it.

If you would rather do it by hand, delete this one file from your game folder:

Binaries\Retail\dinput8.dll

That is the only file the game ever loads. Deleting it fully disables the mod. The
Reloaded-II folder left behind does nothing on its own and can be deleted too if you want
it gone.

The mod does not change any of the game's own files, so there is nothing to repair or
verify afterwards.


THANKS

Please say what worked and what did not, and which screens said nothing. The screens that
say nothing are the useful bug reports, because they are the ones nobody has found yet.
