﻿Injustice 2 Accessibility
Version 0.6.0
Full install package

WHAT THIS IS

A screen reader mod for the Steam PC version of Injustice 2. It speaks menus,
character select, gear and customization, move lists, tutorials, the Multiverse,
story mode choices, match results and more, through whatever screen reader you
already run (NVDA, JAWS, Narrator, or SAPI as a fallback). Nothing needs to be
configured for speech; it finds your reader on its own.

This package contains everything: the loader, the launcher, the installer, and
the mod itself. If you already have the accessibility mod working and just want
the newer version, you want the smaller update package instead, not this one.


WHAT IS NEW IN VERSION 0 POINT 6

Reporting a problem is now one key.

Press F11 at any time and the mod writes a single zip file into your Documents folder, in
a folder called Injustice 2 Accessibility. It contains every log, the most recent
screenshots and a summary of your setup. Send me that file and I have what I need.

You no longer need to switch diagnostic logging on first, or work out which files to send
from a folder buried inside the game. Your Windows account name is removed from everything
in the file before it is written.

There is also a way to update without downloading by hand. Run Check for Updates, included
here, and it will tell you whether there is a newer version and offer to install it. It
checks the same website you got this from, and refuses to install anything that does not
match what the site says it should be.

Two things people reported after the last release are being worked on and are NOT fixed
here: control customization does not read, and tutorial text reads inconsistently. Both
are real. If you are hitting either, F11 while it happens is exactly what I need.


WHAT YOU NEED FIRST

1. Injustice 2 installed through Steam. This mod does not include the game.
2. The Microsoft .NET 9 Desktop Runtime, 64 bit (x64). Free from Microsoft at
   dotnet.microsoft.com/download/dotnet/9.0 . Pick the entry called
   ".NET Desktop Runtime 9.x, Windows x64 Installer". If the game starts but
   never says "Injustice 2 accessibility loaded", this is almost always the
   missing piece.
3. A screen reader running before you launch the game.


HOW TO INSTALL

1. Unzip this package somewhere convenient, like your desktop.
2. Open the folder named Retail inside it. Select everything in that folder and
   copy it.
3. Go to your Injustice 2 install folder, then into Binaries, then into Retail.
   The usual path is:
   C:\Program Files (x86)\Steam\steamapps\common\Injustice2\Binaries\Retail
   If you are not sure where the game is, in Steam go to Injustice 2, open
   Properties, then Installed Files, then Browse.
4. Paste everything there. Say yes to replacing files if Windows asks. You are
   only adding mod files; no game files are overwritten.
5. In that same Retail folder, find Injustice2_Installer.exe, right click it and
   choose "Run as administrator". Approve the Windows security prompt.
   It will say "Mod installed successfully."
6. Launch Injustice 2 normally from Steam. Within a few seconds of the game
   window appearing you should hear "Injustice 2 accessibility loaded".

Step 5 is required. It writes one Windows registry entry that makes the game
start through the mod launcher, so that Steam, achievements and online play all
keep working normally.

7. Optional, but worth doing once: run Check for Updates, included in this
   folder. From then on it lives in your Documents folder, in a folder called
   Injustice 2 Accessibility, alongside any bug reports you write with F11.
   Running it later tells you if there is a newer version and offers to install
   it, so you never have to repeat steps 1 to 5 for an update.


IF IT DOES NOT SPEAK

Check that a file named AccessKit.log appeared in
Binaries\Retail\Reloaded-II\Mods\Injustice2.Accessibility
If that file is there, the mod loaded and the problem is with speech. If it is
not there, the mod never started; install the .NET 9 Desktop Runtime described
above and run the installer again as administrator.

Some overlays can interfere. If nothing at all happens, try turning off the
Steam overlay for Injustice 2 and any GPU recording overlays.


KEYS

All of these only work while the game window is in the foreground.

F1   Read the whole current screen. This is the catch all. If a screen says
     nothing on its own, press F1.
F4   Read details for whatever you are on. In a tutorial lesson it re-reads the
     full lesson text; on a piece of gear it reads the complete gear card with
     slot, character, stats, set bonus and ability; anywhere else it falls back
     to reading the whole screen.
F6   Take a screenshot into the mod folder. This is a troubleshooting tool for
     reporting problems, not something you need in normal play.
F7   Repeat the control hints for this screen, meaning what each button does
     here.
F8   Repeat the last story mode branching choice.
F9   Repeat the last thing that was spoken, in full.
F10  Turn diagnostic logging on or off. It is off unless you switch it on. See
     the note about logging below.
F11  Write a complete bug report into your Documents folder, in a folder called
     Injustice 2 Accessibility. If anything is wrong, press F11 while it is
     happening and send me that file. This is the most useful thing you can do.

Controller: pushing the right stick down, or clicking it in, repeats the last
line, the same as F9. In a tutorial lesson it re-reads the lesson instead.


WHAT IT READS

Main menus and every list style screen, including the item you are on, its
value, and its description.

Character select, both players, plus stage and arena select.

Customization and gear: the slot you are on, the gear name, rarity and level,
and the stats. Numbers are spoken so you can tell them apart, for example
"loadout total strength 1200" versus "this piece strength 40", and a change like
plus 14 is read as "14 higher than equipped". Set bonuses and the dyes and
shaders screen are included.

Move lists, with the frame data. On a move you hear the name and position, a
short note on what the move does, and then the numbers: move type, start up,
active, recover, damage, block damage, block advantage, hit advantage and
cancel. Columns the game leaves empty are skipped rather than read as "not
applicable". Moves the game marks as ability moves, or as affected by strength
or by an ability, say so. Section headings read their own name. Tagging a move
with the Y button announces the new count, for example "tagged, 1 of 10".

Tutorials: the lesson text, the tip panel, the step counter, the required input
translated from button glyphs into words, and the lesson categories in the Learn
hub.

Multiverse and towers: portal name, description, quest, reward and modifiers.
Brother Eye vault reward popups, mother box openings and loot drops, including
which character a piece of gear is for.

Story mode: the branching "choose your fighter" pick.

Match end: the winner and the gear you unlocked, announced as it is revealed.

Online: guild join pages, and another player's profile or hero card.


ABOUT LOGGING

The mod keeps one small file, AccessKit.log, which records whether it loaded and
what it hooked. That one is always written and stays small.

The detailed diagnostic logs are off. They only start if you press F10, and they
stop again when you press F10 a second time or close the game.

To report a problem you no longer need to collect anything yourself. Press F11 and
send the zip it writes into Documents, Injustice 2 Accessibility. If you can, press
F10 first and reproduce the problem before pressing F11, because the detailed log
makes the report much more useful. If you forget, send it anyway.

If you have used an older build, that folder may already hold a large
AccessKit_dump.log from back when logging ran all the time. It is safe to delete
any file in that folder whose name starts with AccessKit_ while the game is
closed.


KNOWN ROUGH EDGES

The direction announced during story mode quick time events can be wrong. It is
a left or right stick choice; the wording is still being worked on.

The character tutorial list, where you pick which tutorial to run, does not read
well yet.

Control customization does not read. Reported after the 26 August release. The
list of options reads, but the screen where you actually reassign buttons does
not tell the mod which one you are on, so it cannot say. Being worked on.

Tutorial text can read inconsistently, particularly in the basic tutorial. Also
reported after the last release, also being worked on.

Guild screens other than the join page, the sell popup for individual items, and
some detail panels are not covered yet.


UNINSTALLING

Open a command prompt in the Binaries\Retail folder and run:
Injustice2_Installer.exe /uninstall
Run it as administrator. It will say "Mod uninstalled. The game will now launch
without the mod." The game then starts normally with no mod. You can also just
delete the mod files afterward if you want them gone.


CREDITS

The original Injustice 2 accessibility mod, the launcher and the installer are
by Amethyst. This build extends that work with a lot of additional screen
coverage. The loader underneath is Reloaded II by Sewer56, and speech goes
through the prism library.
