﻿<#
    AccessKit updater (Injustice 2) -- checks for a newer build and applies it.

    ============================== HOW THIS WORKS ==============================
    There is no server. `version.json` is a static file served by GitHub Pages from the
    same site that already hosts the download, so there is nothing to run, patch or
    attack. This script fetches it, compares against a stamp file written at install
    time, and if a newer build exists: downloads the zip, VERIFIES ITS SHA-256, extracts
    it to a temp folder and runs that package's own install.ps1.

    *The hash check is the one part that is not optional.* An updater downloads and
    installs code; that is the single place where a mistake actually matters. If the
    hash does not match what version.json says, this refuses to install and says so.

    ============================== PER-GAME CONFIG =============================
    This file is COPIED per game rather than shared, exactly like the mods themselves --
    see "do not merge the readers". Only the CONFIG block below differs between copies,
    so a change to one game can never break the other. Port fixes across by hand.
#>

[CmdletBinding()]
param(
    # Skip the "an update is available, install it?" prompt. For unattended re-runs.
    [switch] $Yes,
    # Report what would happen and change nothing.
    [switch] $CheckOnly,
    # Override auto-detection when the game is not in a standard Steam library.
    [string] $GamePath
)

# ------------------------------- CONFIG (Injustice 2) ------------------------
$GameKey      = 'ij2'
$DisplayName  = 'Injustice 2 Accessibility'
$VersionUrl   = 'https://www.gigasoundproject.com/mods/version.json'
$StampFile    = 'accesskit_version.txt'
$SteamFolder  = 'Injustice2'
$MarkerPath   = 'Binaries\Retail\Injustice2.exe'   # proves we found the right folder
# -----------------------------------------------------------------------------

$ErrorActionPreference = 'Stop'

function Say([string] $m) { Write-Host $m }

<#
    Wait for the user, but never DIE waiting. Read-Host throws outright when the host is
    non-interactive (a scheduled run, a CI check, another script calling this one), which
    would turn a clean "you are up to date" into a red error. The pause is a courtesy for
    double-click users; it must not be load-bearing.
#>
function Pause-IfInteractive {
    try { Read-Host 'Press Enter to close' | Out-Null } catch { }
}

function Fail([string] $m) {
    Write-Host ''
    Write-Host "PROBLEM: $m"
    Write-Host ''
    Write-Host 'Nothing was changed. Your current install is untouched.'
    Pause-IfInteractive
    exit 1
}

function Test-GameFolder([string] $p) {
    if ([string]::IsNullOrWhiteSpace($p)) { return $false }
    return (Test-Path (Join-Path $p $MarkerPath))
}

<#
    Find the game by reading Steam's own library list. Same approach as install.ps1 --
    libraryfolders.vdf lists every library root, including ones on other drives, which
    is why we do not just guess C:\Program Files (x86)\Steam.
#>
function Find-Game {
    $roots = @()
    foreach ($base in @("${env:ProgramFiles(x86)}\Steam", "$env:ProgramFiles\Steam", 'C:\Steam')) {
        $vdf = Join-Path $base 'steamapps\libraryfolders.vdf'
        if (-not (Test-Path $vdf)) { continue }
        $roots += $base
        foreach ($line in (Get-Content $vdf)) {
            if ($line -match '"path"\s+"([^"]+)"') {
                $roots += ($matches[1] -replace '\\\\', '\')
            }
        }
    }
    foreach ($r in ($roots | Select-Object -Unique)) {
        $candidate = Join-Path $r "steamapps\common\$SteamFolder"
        if (Test-GameFolder $candidate) { return $candidate }
    }
    return $null
}

function Get-InstalledVersion([string] $gameDir) {
    $stamp = Join-Path $gameDir $StampFile
    if (-not (Test-Path $stamp)) { return $null }
    try {
        $raw = (Get-Content $stamp -Raw).Trim()
        if ($raw.Length -gt 0) { return $raw }
    } catch { }
    return $null
}

<#
    Compare two dotted version strings numerically. [version] handles 0.6.0 vs 0.10.0
    correctly, where a string compare would say 0.6.0 is newer. Falls back to a string
    inequality test if either side is not parseable, which at worst offers an update
    that is not needed rather than hiding one that is.
#>
function Test-IsNewer([string] $candidate, [string] $current) {
    if ([string]::IsNullOrWhiteSpace($current)) { return $true }
    try {
        return ([version] $candidate) -gt ([version] $current)
    } catch {
        return ($candidate -ne $current)
    }
}

# ============================== 1. locate ====================================

Say ''
Say "$DisplayName -- check for updates"
Say ''

if ([string]::IsNullOrWhiteSpace($GamePath)) { $GamePath = Find-Game }
if (-not (Test-GameFolder $GamePath)) {
    Fail ("Could not find the game. Run this again with the folder, for example:`r`n" +
          "  update.ps1 -GamePath ""D:\Steam\steamapps\common\$SteamFolder""")
}
Say "Game folder     : $GamePath"

$installed = Get-InstalledVersion $GamePath
if ($null -eq $installed) {
    Say 'Installed       : unknown (no version stamp -- an older build, probably)'
} else {
    Say "Installed       : $installed"
}

# ============================== 2. ask the site ==============================

Say 'Checking for a newer version...'
try {
    # TLS 1.2 is not the default on stock PowerShell 5.1 and GitHub Pages requires it.
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $resp = Invoke-WebRequest -Uri $VersionUrl -UseBasicParsing -TimeoutSec 30

    # .Content is a string when the server sends a text Content-Type and a byte[] when it
    # does not. Do not assume: decode explicitly, and strip a leading byte-order mark,
    # which ConvertFrom-Json will not accept.
    $raw = $resp.Content
    if ($raw -is [byte[]]) { $raw = [Text.Encoding]::UTF8.GetString($raw) }
    $raw = $raw -replace '^ï»¿', ''
    $raw = $raw.TrimStart([char]0xFEFF, [char]0x200B).Trim()

    $all = $raw | ConvertFrom-Json
} catch {
    Fail ("Could not reach $VersionUrl`r`n" +
          "  $($_.Exception.Message)`r`n" +
          '  Check your internet connection and try again.')
}

$info = $all.$GameKey
if ($null -eq $info) { Fail "version.json has no entry for '$GameKey'." }
foreach ($field in @('version', 'url', 'sha256')) {
    if ([string]::IsNullOrWhiteSpace($info.$field)) { Fail "version.json entry for '$GameKey' is missing '$field'." }
}

Say "Latest          : $($info.version)"
if ($info.notes) { Say "What is new     : $($info.notes)" }
Say ''

if (-not (Test-IsNewer $info.version $installed)) {
    Say 'You already have the latest version. Nothing to do.'
    Pause-IfInteractive
    exit 0
}

Say "An update is available: $($info.version)"
if ($CheckOnly) { Say '(check only -- not installing)'; Pause-IfInteractive; exit 0 }

if (-not $Yes) {
    $answer = ''
    try { $answer = Read-Host 'Download and install it now? (Y/N)' }
    catch { Say 'Cannot prompt here. Re-run with -Yes to install without asking.'; exit 0 }
    if ($answer -notmatch '^[Yy]') { Say 'Cancelled. Nothing was changed.'; exit 0 }
}

# ============================== 3. download ==================================

# Refuse to install over a running game -- the DLLs are locked and a half-applied
# update is far worse than a postponed one.
if (Get-Process -Name 'Injustice2', 'Injustice2_Launcher' -ErrorAction SilentlyContinue) {
    Fail 'The game is running. Close it completely, then run this again.'
}

$work = Join-Path ([IO.Path]::GetTempPath()) ("accesskit_" + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work -Force | Out-Null
$zipPath = Join-Path $work 'update.zip'

try {
    Say 'Downloading...'
    Invoke-WebRequest -Uri $info.url -OutFile $zipPath -UseBasicParsing -TimeoutSec 600

    # ---------------------- 4. VERIFY BEFORE TRUSTING ------------------------
    Say 'Checking the download...'
    $actual = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash
    $expect = $info.sha256.Trim()
    if ($actual -ne $expect.ToUpperInvariant() -and $actual -ne $expect) {
        Fail ("The downloaded file does not match what the site says it should be.`r`n" +
              "  expected $expect`r`n" +
              "  actual   $actual`r`n" +
              '  NOTHING WAS INSTALLED. Try again; if it keeps happening, say so.')
    }
    Say 'Download verified.'

    if ($info.size -and ((Get-Item $zipPath).Length -ne [int64] $info.size)) {
        Say "  (note: size differs from version.json, but the hash matched -- continuing)"
    }

    # ---------------------- 5. apply -----------------------------------------
    <#
        Injustice 2 installs by copying the package's Retail folder over
        <game>\Binaries\Retail, then running Injustice2_Installer.exe ONCE as
        administrator to write the IFEO registry entry that starts the game through the
        mod launcher.

        *An update does not need that registry step* -- it is already there from the
        original install, and it points at a launcher whose name does not change. So this
        copies files and stops, which means no elevation prompt and nothing touching the
        registry. That is also exactly what the hand-made UPDATE zip has always done.

        If a future release ever DOES change the launcher or the registry side, set
        "fullInstall": true on this game's entry in version.json and the check below
        sends the user to the full package instead of half-applying it.
    #>
    if ($info.fullInstall -eq $true) {
        Say ''
        Say 'This release needs a full reinstall rather than a file update.'
        Say "Download and follow the readme here: $($info.url)"
        Pause-IfInteractive
        exit 0
    }

    Say 'Extracting...'
    $unpack = Join-Path $work 'unpacked'
    Expand-Archive -Path $zipPath -DestinationPath $unpack -Force

    $retail = Get-ChildItem -Path $unpack -Directory -Filter 'Retail' -Recurse | Select-Object -First 1
    if ($null -eq $retail) { Fail 'The downloaded package has no Retail folder in it.' }

    $dest = Join-Path $GamePath 'Binaries\Retail'
    if (-not (Test-Path $dest)) { Fail "Expected folder not found: $dest" }

    Say 'Installing...'
    Copy-Item -Path (Join-Path $retail.FullName '*') -Destination $dest -Recurse -Force
    Say "  copied into $dest"

    # A copy-based update overwrites but never DELETES, so a file that has stopped shipping
    # lingers forever. Only one ever has: the debug symbols beside the mod DLL, which older
    # builds shipped and the old readme told people to remove by hand. Do it for them.
    $stalePdb = Join-Path $dest 'Reloaded-II\Mods\Injustice2.Accessibility\Injustice2.Accessibility.pdb'
    if (Test-Path $stalePdb) {
        try { Remove-Item $stalePdb -Force; Say '  removed a leftover debug file from an older build' } catch { }
    }

    <#
        *Repair AppConfig.json.* Reloaded-II stores the game's ABSOLUTE path in
        Reloaded-II\Apps\injustice2.exe\AppConfig.json, and this package ships a prebuilt
        copy pointing at the default Steam location -- but Injustice2_Installer.exe only
        writes the IFEO registry key, it never generates this file. So anyone whose Steam
        library is on another drive has been running with a path that does not match their
        install. We know the real path here, so fix it while we are in the folder.
    #>
    $appCfgPath = Join-Path $dest 'Reloaded-II\Apps\injustice2.exe\AppConfig.json'
    if (Test-Path $appCfgPath) {
        try {
            $cfg = (Get-Content $appCfgPath -Raw) | ConvertFrom-Json
            $wantExe = Join-Path $dest 'Injustice2.exe'
            if ($cfg.AppLocation -ne $wantExe -or $cfg.WorkingDirectory -ne $dest) {
                Say '  fixing the stored game path in AppConfig.json'
                Say "    was: $($cfg.AppLocation)"
                Say "    now: $wantExe"
                $cfg.AppLocation      = $wantExe
                $cfg.WorkingDirectory = $dest
                [IO.File]::WriteAllText($appCfgPath, ($cfg | ConvertTo-Json -Depth 5),
                                        (New-Object Text.UTF8Encoding($false)))
            }
        } catch {
            Say "  (could not check AppConfig.json: $($_.Exception.Message))"
        }
    }

    # ---------------------- 6. record what we installed ----------------------
    Set-Content -Path (Join-Path $GamePath $StampFile) -Value $info.version -Encoding utf8

    <#
        Put a copy of this updater in Documents\Injustice 2 Accessibility, beside where F11
        writes bug reports. Injustice 2 installs by hand-copying a folder rather than running
        an installer, so nothing else ever places this script anywhere findable -- without
        this, the updater only exists wherever the user happened to unzip the package, and
        it is gone the moment they tidy up.
    #>
    try {
        $docs = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Injustice 2 Accessibility'
        New-Item -ItemType Directory -Force $docs | Out-Null
        $self = $MyInvocation.MyCommand.Path
        $here = Split-Path -Parent $self
        Copy-Item $self (Join-Path $docs 'update.ps1') -Force
        $bat = Join-Path $here 'Check for Updates.bat'
        if (Test-Path $bat) { Copy-Item $bat $docs -Force }
        Say "Check for Updates is now also in Documents, Injustice 2 Accessibility."
    } catch {
        Say "  (could not copy the updater into Documents: $($_.Exception.Message))"
    }

    Say ''
    Say "Updated to $($info.version)."
    Say 'Start the game as usual.'
}
finally {
    try { Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue } catch { }
}

Pause-IfInteractive
