================================================================================
                        DRUNKIN CRUNCH ROYALE
                         Tower Defense Game
================================================================================

ABOUT
-----
Drunkin Crunch Royale is an audio-based tower defense game designed for blind
and visually impaired players. Navigate a 31x31 grid, summon monsters, and
destroy enemy towers using only sound and screen reader feedback.

================================================================================
HOW TO PLAY
================================================================================

OBJECTIVE
---------
Destroy one enemy side tower AND the enemy center tower to win.
Defend your own center tower - if it falls, you lose!

TEAMS
-----
At game start, you're randomly assigned RED or BLUE team.
The AI controls the opposing team.

FIELD LAYOUT
------------
Grid: 31 wide (X: 0-30) by 31 tall (Y: 0-30)

Red Team Towers:  Left (5, 8)  Center (15, 3)  Right (25, 8)
Blue Team Towers: Left (5, 22) Center (15, 27) Right (25, 22)

Field Divider: Y = 15
Red team spawns: Y 0-14
Blue team spawns: Y 16-30

Bridge Crossings (for ground units): X = 5, 15, 25

Prostate JUICE SYSTEM
------------
Starting Juice: 7
Maximum Juice: 10

Prostate Juice regenerates based on match time:
- 0-2 minutes: 1 juice every 4 seconds
- 2-4 minutes: 1 juice every 2 seconds
- 4-6 minutes: 1 juice every 500ms
- 6-8 minutes: OVERCLOCK - same as 4-6 minutes

================================================================================
CONTROLS
================================================================================

MOVEMENT
--------
Arrow Keys    - Move one tile in that direction
J             - Jump to X = 5
K             - Jump to X = 15
L             - Jump to X = 25
U             - Jump to Y = 3
I             - Jump to Y = 15
O             - Jump to Y = 27

CARD MANAGEMENT
---------------
A             - Cycle to previous card
D             - Cycle to next card
W             - Hear current card details
S             - Check your juice amount
SPACE         - Summon selected card (if you have enough juice)

INFORMATION
-----------
T             - Announce your team (red or blue)
C             - Announce your current coordinates

TOWER HEALTH
------------
YOUR TOWERS:
1             - Left tower health
2             - Center tower health
3             - Right tower health

ENEMY TOWERS:
4             - Left tower health
5             - Center tower health
6             - Right tower health

STATS SCREEN (after match ends):
Arrow Keys    - Repeat stats
ENTER         - Return to main menu

================================================================================
GAME RULES
================================================================================

SPAWNING
--------
- You can only spawn in your team's field (see FIELD LAYOUT above)
- Ground units can only cross to other field at bridges (X = 5, 15, 25)
- Air units can cross anywhere
- Bomb units can be placed anywhere on the map

MONSTER BEHAVIOR
----------------
- Monsters automatically path toward enemy towers
- If an enemy enters their seeing range (default 5 tiles), they'll attack it
- Monsters on the same team never attack each other
- Once a monster starts attacking, it continues until the target dies
- Special units have unique behaviors (Necromancer multi-target, Boom Bunny explodes, etc.)

TARGETING RULES
---------------
- Side towers must be destroyed before the center tower becomes targetable
- Your monsters will automatically veer toward side towers first
- After one side tower falls, monsters can attack the center tower

================================================================================
TOWERS
================================================================================

CENTER TOWER (X = 15)
---------------------
Health: 3,000
Damage: 300 per hit
Attack Speed: 1500ms
Range: 6 tiles
Sound: center_cannon.ogg
Material: Stone

SIDE TOWERS (X = 5 and 25)
---------------------------
Health: 1,500
Damage: 150 per hit
Attack Speed: 750ms
Range: 5 tiles
Sound: side_crossbow.ogg
Material: Wood

TOWER SOUNDS
------------
All tower sounds play at their location (3D positioned audio):
- Attack sounds when firing (center_cannon.ogg or side_crossbow.ogg)
- Hit sounds play on enemies hit by towers (center_hit*.ogg, side_hit*.ogg)
- Damage sounds based on percentage (woodhit10.ogg through woodhit90.ogg for side towers,
  stonehit10.ogg through stonehit90.ogg for center tower)
- Destruction sounds (wood_destroy.ogg or stone_destroy.ogg) when destroyed
- Towers ignore Blue Ball bombs (can safely place anywhere)

================================================================================
MONSTER CARDS
================================================================================

GRUNT WARBAND - 3 Juice
------------------------
Summons: 5 Grunts
Health: 250 each
Damage: 50
Attack Speed: 750ms
Movement: 500ms
Range: 1 tile
Type: Ground

BONEMEN - 1 Juice
-----------------
Summons: 3 Skeletons
Health: 60 each
Damage: 50
Attack Speed: 800ms
Movement: 450ms
Range: 1 tile
Type: Ground

BERSERKER - 4 Juice
-------------------
Health: 600
Damage: 160
Attack Speed: 900ms
Movement: 300ms (fast!)
Range: 1 tile
Type: Ground
SPECIAL: Berserk mode - doubles attack speed for 2 seconds with 5 second cooldown

BALLSY MC BALLERSON - 5 Juice
------------------------------
Health: 2000 (tank!)
Damage: 100
Attack Speed: 750ms
Movement: 1200ms (slow)
Range: 2 tiles
Type: Ground

NECROMANCER - 5 Juice
---------------------
Health: 400
Damage: 50 (hits up to 4 targets at once!)
Attack Speed: 500ms
Movement: 750ms
Range: 5 tiles (3 tiles vs towers)
Type: Ground
SPECIAL: Summons a skeleton every 4 seconds

Necromancer's Skeleton Stats:
- Health: 60
- Damage: 35
- Attack Speed: 1100ms
- Movement: 350ms
- Range: 1 tile

BIG ANGRY BIRD - 4 Juice
-------------------------
Health: 600
Damage: 200
Attack Speed: 500ms
Movement: 350ms
Range: 1 tile
Type: Air
SPECIAL: Every 5 seconds, performs swoop attack (double damage, then
         doubles attack speed for 2 seconds)

BLUE BALL - 4 Juice
-------------------
Type: Bomb (can be placed anywhere!)
Damage: 190 at center
        100 to adjacent tiles
Special: Damages all enemies in blast radius
Note: Towers ignore this unit!

DRUNKATINE - 5 Juice
--------------------
Health: 800
Damage: 80
Attack Speed: 750ms
Movement: 600ms
Range: 4 tiles
Type: Ground, Projectile
SPECIAL: Juice Bomb - fires projectile with 10 tile range every 5 seconds
         Deals 90 damage at center, 45 splash damage to adjacent tiles

BOOM BUNNY - 4 Juice
---------------------
Health: 500
Movement: 450ms
Range: Explodes when enemy in 5 tile range!
Type: Ground, Suicide Bomber
SPECIAL: Laughs (800ms), then explodes dealing 500 damage in 5 tile radius
         If killed before explosion, waits 400ms then explodes for 100 damage

================================================================================
AUDIO DESIGN
================================================================================

3D POSITIONAL AUDIO
-------------------
All monster and tower sounds are positioned on the grid. Move around to
locate enemies and towers by sound. The closer you are, the louder they are.

MONSTER SOUNDS
--------------
Each monster has unique sounds that play at their location:
- attack.ogg - When they attack
- step.ogg - When they move
- battlecry.ogg - When summoned
- taunt.ogg - Random taunts during battle
- hit.ogg - When their attack lands (plays at TARGET location)
- death.ogg - When they die
- loop.ogg - Projectile travel sound (Drunkatine)
- special.ogg - Special abilities (Necromancer summons)

GENERAL SOUNDS (2D/Stationary)
------------------------------
- game_beginning.ogg - Plays at game start (5 second preparation)
- summon.ogg - When you spawn a monster
- win.ogg - You won the match!
- won.ogg - You destroyed an enemy tower
- lose.ogg - You lost the match
- lost.ogg - Your tower was destroyed
- click.ogg - Movement confirmation
- card.ogg - Cycling through cards

UI SOUNDS
---------
- menuclick.ogg - Menu navigation
- menuenter.ogg - Menu selection

================================================================================
GAME MODES
================================================================================

START GAME
----------
Normal mode with AI opponent. Win by destroying enemy towers before they
destroy yours!

PRACTICE MODE
-------------
AI doesn't spawn monsters. Perfect for learning controls, testing cards,
and exploring the audio positioning system.

================================================================================
TIPS & STRATEGIES
================================================================================

1. Use the quick jump keys (J, K, L, U, I, O) to quickly navigate to
   important positions like bridges and towers.

2. Listen carefully to 3D audio positioning to locate enemy monsters
   and towers.

3. Check enemy tower health (keys 4, 5, 6) before committing expensive
   units to an attack.

4. Remember: You must destroy a side tower before you can attack the
   center tower.

5. Swarm units (Grunt Warband, Horde of Bonemen) are cheap and effective
   for overwhelming defenses.

6. Use tanks like Ballsy MC Ballerson to absorb tower damage while your
   other units attack.

7. Air units (Big Angry Bird) can cross anywhere - use them to flank!

8. Drunkatine's long range (4 tiles) and Juice Bomb (10 tile range) makes
   him great for harassing from safety.

9. Blue Ball bombs can be placed anywhere - use them to snipe wounded
   towers or clustered enemies.

10. The Necromancer creates a steady stream of skeletons - great for
    continuous pressure!

11. Boom Bunny is a powerful suicide bomber - 500 damage in a huge radius!
    Send him into enemy groups or at towers for massive damage.

12. Bonemen (1 juice) is the cheapest card - perfect for quick pressure
    or spending excess juice before it caps at 10!

================================================================================
TROUBLESHOOTING
================================================================================

If the game crashes or has errors, check drunkin_crunch_royale.log in the
game directory. This file contains detailed error information that can help
with bug reports.

================================================================================
CREDITS
================================================================================

Drunkin Crunch Royale - An audio-first tower defense experience
Designed for accessibility and immersive 3D audio gameplay, or something.

Enjoy the battle!

================================================================================
