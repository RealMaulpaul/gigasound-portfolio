# Drunkin Crunch Royale

A tower defense game with audio-first design for screen reader accessibility, featuring strategic gameplay on a 31x31 grid with Red vs Blue team battles.

## Features

- **Audio-First Design**: All game elements have 3D positional audio and screen reader announcements
- **9 Unique Units**: From basic grunts to special units like the Necromancer, Boom Bunny, and Blue Ball bomb
- **Strategic Gameplay**: Resource management, card deck system, and tactical positioning
- **AI Opponent**: Opportunistic AI that manages resources and spawns units strategically
- **Accessible Controls**: Keyboard-only interface with screen reader support

## Installation

```bash
pip install -r requirements.txt
```

## How to Play

### Goal
Destroy one enemy side tower plus their center tower to win. Protect your own center tower!

### Controls

**Menu**:
- ↑/↓ - Navigate options
- Enter - Select

**In-Game Movement**:
- Arrow keys - Move one tile
- J/K/L - Jump to X position (5/15/25)
- U/I/O - Jump to Y position (3/15/27)

**Card Management**:
- A/D - Cycle left/right through cards
- W - Get card info
- S - Check juice
- Space - Spawn monster

**Tower Health**:
- 1/2/3 - Check your left/center/right tower health
- 4/5/6 - Check enemy left/center/right tower health

**End Game**:
- Arrow keys - Repeat stats
- Enter - Return to menu

## Units

### Towers
- **Center Tower**: 3000 HP, 300 damage, 1500ms attack speed, 6 tile range
- **Side Towers**: 1500 HP, 150 damage, 750ms attack speed, 5 tile range

### Cards

1. **Grunt Warband** (3 juice) - Spawns 5 grunts with 250 HP, 50 damage, 750ms attack speed
2. **Bonemen** (1 juice) - Spawns 3 skeletons with 60 HP, 50 damage, 800ms attack speed
3. **Berserker** (4 juice) - 600 HP, 160 damage, fast movement. Special: Berserk mode doubles attack speed for 2 seconds
4. **Ballsy MC Ballerson** (5 juice) - 2000 HP tank, 100 damage, range 2, slow movement
5. **Necromancer** (5 juice) - 400 HP, 50 damage to up to 4 targets, 5 tile range (3 vs towers). Summons skeletons every 4 seconds
6. **Big Angry Bird** (4 juice) - 600 HP air unit with swoop attack dealing double damage every 5 seconds
7. **Blue Ball** (4 juice) - Bomb: 190 damage at center, 100 to adjacent tiles (can place anywhere!)
8. **Drunkatine** (5 juice) - 800 HP, 80 damage, 4 tile range. Juice bomb special: 90 center damage, 45 splash, 10 tile range
9. **Boom Bunny** (4 juice) - 500 HP suicide bomber. Explodes when enemy enters 5 tile range: 500 damage in 5 tile radius. If killed early, deals 100 damage instead

## Game Mechanics

### Juice (Resources)
- Starts at 7, max is 10
- Regenerates faster as the game progresses:
  - 0-2 min: 1 juice every 4 seconds
  - 2-4 min: 1 juice every 2 seconds
  - 4-6 min: 1 juice every 500ms
  - 6-8 min: Overclock mode (same speed as 4-6 min)

### Movement Restrictions
- **Ground Units**: Can only cross between fields at bridges (X=5, 15, 25)
- **Air Units**: Can move anywhere
- **Bombs**: Can be placed anywhere

### Monster Behavior
- Monsters pathfind to nearest enemy tower
- Will automatically switch to attack nearby enemies (within seeing range, typically 5 tiles)
- Automatically engage enemies in range
- Towers ignore bomb-type units (Blue Ball)

## Technical Details

- Built with Python and the Cosmos audio game library
- 3D positional audio with HRTF support
- Screen reader support for all game elements (via Cosmos ScreenReader API)
- Audio-only interface (no graphics required)
- Uses OpenAL for spatial audio

## Running the Game

```bash
python main.py
```

## Credits

Designed for accessibility with audio-first gameplay and full screen reader support.
