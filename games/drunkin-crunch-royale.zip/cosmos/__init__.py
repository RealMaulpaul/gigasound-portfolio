"""
Cosmos - Audio Game Library for Python

A library for creating audio games with 3D spatial audio, screen reader support,
and accessible input handling.

Example:
    >>> import cosmos
    >>> cosmos.init()
    >>> manager = cosmos.SoundManager()
    >>> sound = manager.create_sound()
    >>> sound.load("music.ogg")
    >>> sound.play()
"""

from . import _ffi

__version__ = "0.1.0"
__all__ = [
    "init",
    "terminate",
    "Window",
    "ScreenReader",
    "SoundManager",
    "Sound",
    "Key",
]


def init():
    """Initialize the Cosmos runtime. Must be called before using any other functions."""
    _ffi.init()


def terminate():
    """Terminate the Cosmos runtime. Call before program exit."""
    _ffi.terminate()


class Key:
    """Keyboard key constants."""

    @staticmethod
    def _get(name):
        return getattr(_ffi.lib, f"cosmos_key_{name}")()

    A = property(lambda self: _ffi.lib.cosmos_key_a())
    B = property(lambda self: _ffi.lib.cosmos_key_b())
    C = property(lambda self: _ffi.lib.cosmos_key_c())
    D = property(lambda self: _ffi.lib.cosmos_key_d())
    E = property(lambda self: _ffi.lib.cosmos_key_e())
    F = property(lambda self: _ffi.lib.cosmos_key_f())
    G = property(lambda self: _ffi.lib.cosmos_key_g())
    H = property(lambda self: _ffi.lib.cosmos_key_h())
    I = property(lambda self: _ffi.lib.cosmos_key_i())
    J = property(lambda self: _ffi.lib.cosmos_key_j())
    K = property(lambda self: _ffi.lib.cosmos_key_k())
    L = property(lambda self: _ffi.lib.cosmos_key_l())
    M = property(lambda self: _ffi.lib.cosmos_key_m())
    N = property(lambda self: _ffi.lib.cosmos_key_n())
    O = property(lambda self: _ffi.lib.cosmos_key_o())
    P = property(lambda self: _ffi.lib.cosmos_key_p())
    Q = property(lambda self: _ffi.lib.cosmos_key_q())
    R = property(lambda self: _ffi.lib.cosmos_key_r())
    S = property(lambda self: _ffi.lib.cosmos_key_s())
    T = property(lambda self: _ffi.lib.cosmos_key_t())
    U = property(lambda self: _ffi.lib.cosmos_key_u())
    V = property(lambda self: _ffi.lib.cosmos_key_v())
    W = property(lambda self: _ffi.lib.cosmos_key_w())
    X = property(lambda self: _ffi.lib.cosmos_key_x())
    Y = property(lambda self: _ffi.lib.cosmos_key_y())
    Z = property(lambda self: _ffi.lib.cosmos_key_z())
    SPACE = property(lambda self: _ffi.lib.cosmos_key_space())
    ESCAPE = property(lambda self: _ffi.lib.cosmos_key_escape())
    ENTER = property(lambda self: _ffi.lib.cosmos_key_enter())
    UP = property(lambda self: _ffi.lib.cosmos_key_up())
    DOWN = property(lambda self: _ffi.lib.cosmos_key_down())
    LEFT = property(lambda self: _ffi.lib.cosmos_key_left())
    RIGHT = property(lambda self: _ffi.lib.cosmos_key_right())


# Create a singleton instance for easy access
class _KeyConstants:
    """Keyboard key constants accessible as class attributes."""

    @property
    def A(self): return _ffi.lib.cosmos_key_a()
    @property
    def B(self): return _ffi.lib.cosmos_key_b()
    @property
    def C(self): return _ffi.lib.cosmos_key_c()
    @property
    def D(self): return _ffi.lib.cosmos_key_d()
    @property
    def E(self): return _ffi.lib.cosmos_key_e()
    @property
    def F(self): return _ffi.lib.cosmos_key_f()
    @property
    def G(self): return _ffi.lib.cosmos_key_g()
    @property
    def H(self): return _ffi.lib.cosmos_key_h()
    @property
    def I(self): return _ffi.lib.cosmos_key_i()
    @property
    def J(self): return _ffi.lib.cosmos_key_j()
    @property
    def K(self): return _ffi.lib.cosmos_key_k()
    @property
    def L(self): return _ffi.lib.cosmos_key_l()
    @property
    def M(self): return _ffi.lib.cosmos_key_m()
    @property
    def N(self): return _ffi.lib.cosmos_key_n()
    @property
    def O(self): return _ffi.lib.cosmos_key_o()
    @property
    def P(self): return _ffi.lib.cosmos_key_p()
    @property
    def Q(self): return _ffi.lib.cosmos_key_q()
    @property
    def R(self): return _ffi.lib.cosmos_key_r()
    @property
    def S(self): return _ffi.lib.cosmos_key_s()
    @property
    def T(self): return _ffi.lib.cosmos_key_t()
    @property
    def U(self): return _ffi.lib.cosmos_key_u()
    @property
    def V(self): return _ffi.lib.cosmos_key_v()
    @property
    def W(self): return _ffi.lib.cosmos_key_w()
    @property
    def X(self): return _ffi.lib.cosmos_key_x()
    @property
    def Y(self): return _ffi.lib.cosmos_key_y()
    @property
    def Z(self): return _ffi.lib.cosmos_key_z()
    @property
    def SPACE(self): return _ffi.lib.cosmos_key_space()
    @property
    def ESCAPE(self): return _ffi.lib.cosmos_key_escape()
    @property
    def ENTER(self): return _ffi.lib.cosmos_key_enter()
    @property
    def UP(self): return _ffi.lib.cosmos_key_up()
    @property
    def DOWN(self): return _ffi.lib.cosmos_key_down()
    @property
    def LEFT(self): return _ffi.lib.cosmos_key_left()
    @property
    def RIGHT(self): return _ffi.lib.cosmos_key_right()

    # Number keys
    @property
    def N0(self): return _ffi.lib.cosmos_key_0()
    @property
    def N1(self): return _ffi.lib.cosmos_key_1()
    @property
    def N2(self): return _ffi.lib.cosmos_key_2()
    @property
    def N3(self): return _ffi.lib.cosmos_key_3()
    @property
    def N4(self): return _ffi.lib.cosmos_key_4()
    @property
    def N5(self): return _ffi.lib.cosmos_key_5()
    @property
    def N6(self): return _ffi.lib.cosmos_key_6()
    @property
    def N7(self): return _ffi.lib.cosmos_key_7()
    @property
    def N8(self): return _ffi.lib.cosmos_key_8()
    @property
    def N9(self): return _ffi.lib.cosmos_key_9()


Key = _KeyConstants()


class Window:
    """
    A window for receiving keyboard input.

    Use as a context manager for automatic cleanup:

        with cosmos.Window("My Game") as window:
            while window.is_open:
                window.update()
                if window.key_pressed(cosmos.Key.ESCAPE):
                    window.close()
    """

    def __init__(self, title: str = "Cosmos"):
        """Create a new window with the given title."""
        self._handle = _ffi.lib.cosmos_window_create(title.encode("utf-8"))
        if self._handle == _ffi.ffi.NULL:
            raise RuntimeError("Failed to create window")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.destroy()
        return False

    def destroy(self):
        """Destroy the window and release resources."""
        if self._handle != _ffi.ffi.NULL:
            _ffi.lib.cosmos_window_destroy(self._handle)
            self._handle = _ffi.ffi.NULL

    @property
    def is_open(self) -> bool:
        """Check if the window is still open."""
        return _ffi.lib.cosmos_window_is_open(self._handle)

    def close(self):
        """Close the window."""
        _ffi.lib.cosmos_window_close(self._handle)

    def update(self):
        """Update the window and process events. Call once per frame."""
        _ffi.lib.cosmos_window_update(self._handle)

    def key_pressed(self, key: int) -> bool:
        """Check if a key was pressed this frame."""
        return _ffi.lib.cosmos_window_key_pressed(self._handle, key)

    def key_held(self, key: int) -> bool:
        """Check if a key is being held down."""
        return _ffi.lib.cosmos_window_key_held(self._handle, key)

    def key_released(self, key: int) -> bool:
        """Check if a key was released this frame."""
        return _ffi.lib.cosmos_window_key_released(self._handle, key)


class ScreenReader:
    """
    Interface for text-to-speech through the system screen reader.

    Example:
        sr = cosmos.ScreenReader()
        if sr.can_speak:
            sr.speak("Hello, world!")
    """

    def __init__(self):
        """Create a new screen reader interface."""
        self._handle = _ffi.lib.cosmos_screenreader_create()
        if self._handle == _ffi.ffi.NULL:
            raise RuntimeError("Failed to create screen reader")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.destroy()
        return False

    def destroy(self):
        """Destroy the screen reader and release resources."""
        if self._handle != _ffi.ffi.NULL:
            _ffi.lib.cosmos_screenreader_destroy(self._handle)
            self._handle = _ffi.ffi.NULL

    @property
    def can_speak(self) -> bool:
        """Check if the screen reader is available and can speak."""
        return _ffi.lib.cosmos_screenreader_can_speak(self._handle)

    def speak(self, text: str):
        """Speak the given text."""
        _ffi.lib.cosmos_screenreader_speak(self._handle, text.encode("utf-8"))

    def stop(self):
        """Stop any current speech."""
        _ffi.lib.cosmos_screenreader_stop(self._handle)

    @property
    def is_speaking(self) -> bool:
        """Check if currently speaking."""
        return _ffi.lib.cosmos_screenreader_is_speaking(self._handle)


class Sound:
    """
    A sound that can be played with 3D positioning.

    Create sounds through SoundManager.create_sound().

    Coordinate system (Y-forward, Z-up):
        - X: left (-) / right (+)
        - Y: backward (-) / forward (+)
        - Z: down (-) / up (+)
    """

    def __init__(self, handle):
        """Internal: create a Sound wrapper from a C handle."""
        self._handle = handle

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.destroy()
        return False

    def destroy(self):
        """Destroy the sound and release resources."""
        if self._handle != _ffi.ffi.NULL:
            _ffi.lib.cosmos_sound_destroy(self._handle)
            self._handle = _ffi.ffi.NULL

    def load(self, filename: str) -> bool:
        """Load audio from a file. Returns True on success."""
        return _ffi.lib.cosmos_sound_load(self._handle, filename.encode("utf-8"))

    def play(self) -> bool:
        """Start playing the sound."""
        return _ffi.lib.cosmos_sound_play(self._handle)

    def stop(self) -> bool:
        """Stop playing and reset to the beginning."""
        return _ffi.lib.cosmos_sound_stop(self._handle)

    def pause(self) -> bool:
        """Pause playback (maintains position)."""
        return _ffi.lib.cosmos_sound_pause(self._handle)

    @property
    def playing(self) -> bool:
        """Check if the sound is currently playing."""
        return _ffi.lib.cosmos_sound_is_playing(self._handle)

    @property
    def at_end(self) -> bool:
        """Check if the sound has finished playing."""
        return _ffi.lib.cosmos_sound_at_end(self._handle)

    @property
    def playback_position(self) -> int:
        """Get/set the current playback position in milliseconds."""
        return _ffi.lib.cosmos_sound_get_playback_position(self._handle)

    @playback_position.setter
    def playback_position(self, value: int):
        _ffi.lib.cosmos_sound_set_playback_position(self._handle, value)

    @property
    def length(self) -> int:
        """Get the total length of the sound in milliseconds."""
        return _ffi.lib.cosmos_sound_get_length(self._handle)

    def set_position(self, x: float, y: float, z: float):
        """Set the 3D position of this sound as a point source."""
        _ffi.lib.cosmos_sound_set_position(self._handle, x, y, z)

    def set_position_ranged(self, minx: float, maxx: float, miny: float, maxy: float, minz: float, maxz: float):
        """Set the 3D position as a ranged AABB (axis-aligned bounding box).

        The sound will appear to come from the closest edge of the box to the listener.
        Useful for ambient sounds that span an area (rivers, rooms, etc.).

        Args:
            minx, maxx: X axis bounds
            miny, maxy: Y axis bounds
            minz, maxz: Z axis bounds
        """
        _ffi.lib.cosmos_sound_set_position_ranged(self._handle, minx, maxx, miny, maxy, minz, maxz)

    @property
    def position(self) -> tuple:
        """Get the current 3D position as (x, y, z). For ranged sounds, returns min corner."""
        return (
            _ffi.lib.cosmos_sound_get_x(self._handle),
            _ffi.lib.cosmos_sound_get_y(self._handle),
            _ffi.lib.cosmos_sound_get_z(self._handle),
        )

    @position.setter
    def position(self, value: tuple):
        """Set the 3D position from (x, y, z) tuple as a point source."""
        x, y, z = value
        self.set_position(x, y, z)

    @property
    def position_ranged(self) -> tuple:
        """Get the AABB bounds as (minx, maxx, miny, maxy, minz, maxz)."""
        return (
            _ffi.lib.cosmos_sound_get_min_x(self._handle),
            _ffi.lib.cosmos_sound_get_max_x(self._handle),
            _ffi.lib.cosmos_sound_get_min_y(self._handle),
            _ffi.lib.cosmos_sound_get_max_y(self._handle),
            _ffi.lib.cosmos_sound_get_min_z(self._handle),
            _ffi.lib.cosmos_sound_get_max_z(self._handle),
        )

    @position_ranged.setter
    def position_ranged(self, value: tuple):
        """Set the AABB bounds from (minx, maxx, miny, maxy, minz, maxz) tuple."""
        minx, maxx, miny, maxy, minz, maxz = value
        self.set_position_ranged(minx, maxx, miny, maxy, minz, maxz)

    @property
    def stationary(self) -> bool:
        """Get/set whether this sound is stationary (doesn't update with listener movement)."""
        return _ffi.lib.cosmos_sound_get_stationary(self._handle)

    @stationary.setter
    def stationary(self, value: bool):
        _ffi.lib.cosmos_sound_set_stationary(self._handle, value)

    @property
    def x(self) -> float:
        """Get X position (left/right)."""
        return _ffi.lib.cosmos_sound_get_x(self._handle)

    @property
    def y(self) -> float:
        """Get Y position (forward/backward)."""
        return _ffi.lib.cosmos_sound_get_y(self._handle)

    @property
    def z(self) -> float:
        """Get Z position (up/down)."""
        return _ffi.lib.cosmos_sound_get_z(self._handle)

    @property
    def volume(self) -> float:
        """Get/set volume (0.0 to 1.0)."""
        return _ffi.lib.cosmos_sound_get_volume(self._handle)

    @volume.setter
    def volume(self, value: float):
        _ffi.lib.cosmos_sound_set_volume(self._handle, value)

    @property
    def pitch(self) -> float:
        """Get/set pitch (1.0 = normal)."""
        return _ffi.lib.cosmos_sound_get_pitch(self._handle)

    @pitch.setter
    def pitch(self, value: float):
        _ffi.lib.cosmos_sound_set_pitch(self._handle, value)

    @property
    def pan(self) -> float:
        """Get/set pan (-1.0 = left, 0 = center, 1.0 = right)."""
        return _ffi.lib.cosmos_sound_get_pan(self._handle)

    @pan.setter
    def pan(self, value: float):
        _ffi.lib.cosmos_sound_set_pan(self._handle, value)

    @property
    def looping(self) -> bool:
        """Get/set whether the sound loops."""
        return _ffi.lib.cosmos_sound_get_looping(self._handle)

    @looping.setter
    def looping(self, value: bool):
        _ffi.lib.cosmos_sound_set_looping(self._handle, value)

    @property
    def hrtf(self) -> bool:
        """Get/set HRTF (3D audio) mode."""
        return _ffi.lib.cosmos_sound_get_hrtf(self._handle)

    @hrtf.setter
    def hrtf(self, value: bool):
        _ffi.lib.cosmos_sound_set_hrtf(self._handle, value)

    @property
    def min_distance(self) -> float:
        """Get/set minimum distance for 3D falloff."""
        return _ffi.lib.cosmos_sound_get_min_distance(self._handle)

    @min_distance.setter
    def min_distance(self, value: float):
        _ffi.lib.cosmos_sound_set_min_distance(self._handle, value)

    @property
    def max_distance(self) -> float:
        """Get/set maximum distance for 3D falloff."""
        return _ffi.lib.cosmos_sound_get_max_distance(self._handle)

    @max_distance.setter
    def max_distance(self, value: float):
        _ffi.lib.cosmos_sound_set_max_distance(self._handle, value)

    @property
    def rolloff(self) -> float:
        """Get/set rolloff factor for distance attenuation."""
        return _ffi.lib.cosmos_sound_get_rolloff(self._handle)

    @rolloff.setter
    def rolloff(self, value: float):
        _ffi.lib.cosmos_sound_set_rolloff(self._handle, value)

    @property
    def pan_step(self) -> float:
        """Get/set pan step (pan amount per unit horizontal distance, default 0.05)."""
        return _ffi.lib.cosmos_sound_get_pan_step(self._handle)

    @pan_step.setter
    def pan_step(self, value: float):
        _ffi.lib.cosmos_sound_set_pan_step(self._handle, value)

    @property
    def volume_step(self) -> float:
        """Get/set volume step (volume reduction per unit distance, default 0.0333)."""
        return _ffi.lib.cosmos_sound_get_volume_step(self._handle)

    @volume_step.setter
    def volume_step(self, value: float):
        _ffi.lib.cosmos_sound_set_volume_step(self._handle, value)

    @property
    def behind_pitch_decrease(self) -> float:
        """Get/set behind pitch decrease (pitch reduction for sounds behind listener, default 0.04)."""
        return _ffi.lib.cosmos_sound_get_behind_pitch_decrease(self._handle)

    @behind_pitch_decrease.setter
    def behind_pitch_decrease(self, value: float):
        _ffi.lib.cosmos_sound_set_behind_pitch_decrease(self._handle, value)

    @property
    def hard_close_pan(self) -> bool:
        """Get/set hard close pan (add extra pan separation for close sounds, default True)."""
        return _ffi.lib.cosmos_sound_get_hard_close_pan(self._handle)

    @hard_close_pan.setter
    def hard_close_pan(self, value: bool):
        _ffi.lib.cosmos_sound_set_hard_close_pan(self._handle, value)


class SoundManager:
    """
    Manages audio playback and the 3D listener position.

    Example:
        manager = cosmos.SoundManager()
        manager.set_listener_position(0, 0, 0)

        sound = manager.create_sound()
        sound.load("footstep.ogg")
        sound.position = (5, 10, 0)  # 5 right, 10 forward
        sound.play()
    """

    def __init__(self):
        """Create a new sound manager."""
        self._handle = _ffi.lib.cosmos_soundmanager_create()
        if self._handle == _ffi.ffi.NULL:
            raise RuntimeError("Failed to create sound manager")
        self._sounds = []  # Keep references to prevent GC

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.destroy()
        return False

    def destroy(self):
        """Destroy the sound manager and all its sounds."""
        # Destroy all sounds first
        for sound in self._sounds:
            sound.destroy()
        self._sounds.clear()

        if self._handle != _ffi.ffi.NULL:
            _ffi.lib.cosmos_soundmanager_destroy(self._handle)
            self._handle = _ffi.ffi.NULL

    def create_sound(self) -> Sound:
        """Create a new sound attached to this manager."""
        handle = _ffi.lib.cosmos_soundmanager_create_sound(self._handle)
        if handle == _ffi.ffi.NULL:
            raise RuntimeError("Failed to create sound")
        sound = Sound(handle)
        self._sounds.append(sound)
        return sound

    def set_listener_position(self, x: float, y: float, z: float):
        """Set the 3D listener position."""
        _ffi.lib.cosmos_soundmanager_set_listener_position(self._handle, x, y, z)

    def set_listener_angle(self, angle: float):
        """Set the listener facing angle (degrees, unit circle: 0 = +X east, 90 = +Y forward)."""
        _ffi.lib.cosmos_soundmanager_set_listener_angle(self._handle, angle)

    def set_listener(self, x: float, y: float, z: float, angle: float):
        """Set both listener position and angle at once (more efficient)."""
        _ffi.lib.cosmos_soundmanager_set_listener(self._handle, x, y, z, angle)

    @property
    def listener_angle(self) -> float:
        """Get/set the listener facing angle in degrees."""
        return _ffi.lib.cosmos_soundmanager_get_listener_angle(self._handle)

    @listener_angle.setter
    def listener_angle(self, value: float):
        self.set_listener_angle(value)

    @property
    def hrtf_available(self) -> bool:
        """Check if HRTF (Steam Audio) is available."""
        return _ffi.lib.cosmos_soundmanager_is_hrtf_available(self._handle)
