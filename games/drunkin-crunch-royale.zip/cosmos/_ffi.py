"""CFFI bindings for Cosmos audio game library."""

import os
import sys
from cffi import FFI

ffi = FFI()

# C declarations from cosmos.h
ffi.cdef("""
    /* Opaque handle types */
    typedef void* cosmos_window_t;
    typedef void* cosmos_screenreader_t;
    typedef void* cosmos_soundmanager_t;
    typedef void* cosmos_sound_t;

    /* Runtime initialization */
    bool cosmos_init(void);
    bool cosmos_terminate(void);

    /* Window functions */
    cosmos_window_t cosmos_window_create(const char* title);
    void cosmos_window_destroy(cosmos_window_t window);
    bool cosmos_window_is_open(cosmos_window_t window);
    void cosmos_window_close(cosmos_window_t window);
    void cosmos_window_update(cosmos_window_t window);
    bool cosmos_window_key_pressed(cosmos_window_t window, int key);
    bool cosmos_window_key_held(cosmos_window_t window, int key);
    bool cosmos_window_key_released(cosmos_window_t window, int key);

    /* Screen reader functions */
    cosmos_screenreader_t cosmos_screenreader_create(void);
    void cosmos_screenreader_destroy(cosmos_screenreader_t sr);
    bool cosmos_screenreader_can_speak(cosmos_screenreader_t sr);
    void cosmos_screenreader_speak(cosmos_screenreader_t sr, const char* text);
    void cosmos_screenreader_stop(cosmos_screenreader_t sr);
    bool cosmos_screenreader_is_speaking(cosmos_screenreader_t sr);

    /* Sound manager functions */
    cosmos_soundmanager_t cosmos_soundmanager_create(void);
    void cosmos_soundmanager_destroy(cosmos_soundmanager_t manager);
    cosmos_sound_t cosmos_soundmanager_create_sound(cosmos_soundmanager_t manager);
    void cosmos_soundmanager_set_listener_position(cosmos_soundmanager_t manager, float x, float y, float z);
    void cosmos_soundmanager_set_listener_angle(cosmos_soundmanager_t manager, float angle);
    void cosmos_soundmanager_set_listener(cosmos_soundmanager_t manager, float x, float y, float z, float angle);
    float cosmos_soundmanager_get_listener_angle(cosmos_soundmanager_t manager);
    bool cosmos_soundmanager_is_hrtf_available(cosmos_soundmanager_t manager);

    /* Sound functions */
    void cosmos_sound_destroy(cosmos_sound_t sound);
    bool cosmos_sound_load(cosmos_sound_t sound, const char* filename);
    bool cosmos_sound_play(cosmos_sound_t sound);
    bool cosmos_sound_stop(cosmos_sound_t sound);
    bool cosmos_sound_pause(cosmos_sound_t sound);
    bool cosmos_sound_is_playing(cosmos_sound_t sound);
    bool cosmos_sound_at_end(cosmos_sound_t sound);
    unsigned long long cosmos_sound_get_playback_position(cosmos_sound_t sound);
    void cosmos_sound_set_playback_position(cosmos_sound_t sound, unsigned long long position_ms);
    unsigned long long cosmos_sound_get_length(cosmos_sound_t sound);
    void cosmos_sound_set_position(cosmos_sound_t sound, float x, float y, float z);
    void cosmos_sound_set_position_ranged(cosmos_sound_t sound, float minx, float maxx, float miny, float maxy, float minz, float maxz);
    float cosmos_sound_get_x(cosmos_sound_t sound);
    float cosmos_sound_get_y(cosmos_sound_t sound);
    float cosmos_sound_get_z(cosmos_sound_t sound);
    float cosmos_sound_get_min_x(cosmos_sound_t sound);
    float cosmos_sound_get_max_x(cosmos_sound_t sound);
    float cosmos_sound_get_min_y(cosmos_sound_t sound);
    float cosmos_sound_get_max_y(cosmos_sound_t sound);
    float cosmos_sound_get_min_z(cosmos_sound_t sound);
    float cosmos_sound_get_max_z(cosmos_sound_t sound);
    void cosmos_sound_set_stationary(cosmos_sound_t sound, bool stationary);
    bool cosmos_sound_get_stationary(cosmos_sound_t sound);
    void cosmos_sound_set_volume(cosmos_sound_t sound, float volume);
    float cosmos_sound_get_volume(cosmos_sound_t sound);
    void cosmos_sound_set_pitch(cosmos_sound_t sound, float pitch);
    float cosmos_sound_get_pitch(cosmos_sound_t sound);
    void cosmos_sound_set_pan(cosmos_sound_t sound, float pan);
    float cosmos_sound_get_pan(cosmos_sound_t sound);
    void cosmos_sound_set_looping(cosmos_sound_t sound, bool looping);
    bool cosmos_sound_get_looping(cosmos_sound_t sound);
    void cosmos_sound_set_hrtf(cosmos_sound_t sound, bool enabled);
    bool cosmos_sound_get_hrtf(cosmos_sound_t sound);
    void cosmos_sound_set_min_distance(cosmos_sound_t sound, float dist);
    float cosmos_sound_get_min_distance(cosmos_sound_t sound);
    void cosmos_sound_set_max_distance(cosmos_sound_t sound, float dist);
    float cosmos_sound_get_max_distance(cosmos_sound_t sound);
    void cosmos_sound_set_rolloff(cosmos_sound_t sound, float rolloff);
    float cosmos_sound_get_rolloff(cosmos_sound_t sound);
    void cosmos_sound_set_pan_step(cosmos_sound_t sound, float step);
    float cosmos_sound_get_pan_step(cosmos_sound_t sound);
    void cosmos_sound_set_volume_step(cosmos_sound_t sound, float step);
    float cosmos_sound_get_volume_step(cosmos_sound_t sound);
    void cosmos_sound_set_behind_pitch_decrease(cosmos_sound_t sound, float decrease);
    float cosmos_sound_get_behind_pitch_decrease(cosmos_sound_t sound);
    void cosmos_sound_set_hard_close_pan(cosmos_sound_t sound, bool enabled);
    bool cosmos_sound_get_hard_close_pan(cosmos_sound_t sound);

    /* Key code functions */
    int cosmos_key_a(void);
    int cosmos_key_b(void);
    int cosmos_key_c(void);
    int cosmos_key_d(void);
    int cosmos_key_e(void);
    int cosmos_key_f(void);
    int cosmos_key_g(void);
    int cosmos_key_h(void);
    int cosmos_key_i(void);
    int cosmos_key_j(void);
    int cosmos_key_k(void);
    int cosmos_key_l(void);
    int cosmos_key_m(void);
    int cosmos_key_n(void);
    int cosmos_key_o(void);
    int cosmos_key_p(void);
    int cosmos_key_q(void);
    int cosmos_key_r(void);
    int cosmos_key_s(void);
    int cosmos_key_t(void);
    int cosmos_key_u(void);
    int cosmos_key_v(void);
    int cosmos_key_w(void);
    int cosmos_key_x(void);
    int cosmos_key_y(void);
    int cosmos_key_z(void);
    int cosmos_key_space(void);
    int cosmos_key_escape(void);
    int cosmos_key_enter(void);
    int cosmos_key_up(void);
    int cosmos_key_down(void);
    int cosmos_key_left(void);
    int cosmos_key_right(void);

    /* Number keys */
    int cosmos_key_0(void);
    int cosmos_key_1(void);
    int cosmos_key_2(void);
    int cosmos_key_3(void);
    int cosmos_key_4(void);
    int cosmos_key_5(void);
    int cosmos_key_6(void);
    int cosmos_key_7(void);
    int cosmos_key_8(void);
    int cosmos_key_9(void);
""")


def _find_library():
    """Find the cosmos library based on platform and common locations."""
    if sys.platform == "win32":
        lib_name = "cosmos.dll"
    elif sys.platform == "darwin":
        lib_name = "libcosmos.dylib"
    else:
        lib_name = "libcosmos.so"

    # Search paths in order of preference
    search_paths = [
        # Same directory as this module
        os.path.dirname(__file__),
        # Parent of package (python/)
        os.path.dirname(os.path.dirname(__file__)),
        # Project root (two levels up from python/cosmos/)
        os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
        # Current working directory
        os.getcwd(),
        # COSMOS_LIB_PATH environment variable
        os.environ.get("COSMOS_LIB_PATH", ""),
    ]

    for path in search_paths:
        if not path:
            continue
        lib_path = os.path.join(path, lib_name)
        if os.path.exists(lib_path):
            return lib_path

    # Fall back to system library search
    return lib_name


# Load the library
_lib_path = _find_library()
lib = ffi.dlopen(_lib_path)

# Track initialization state
_initialized = False


def init():
    """Initialize the Cosmos runtime. Must be called before using any other functions."""
    global _initialized
    if not _initialized:
        if not lib.cosmos_init():
            raise RuntimeError("Failed to initialize Cosmos runtime")
        _initialized = True


def terminate():
    """Terminate the Cosmos runtime. Call before program exit."""
    global _initialized
    if _initialized:
        lib.cosmos_terminate()
        _initialized = False
